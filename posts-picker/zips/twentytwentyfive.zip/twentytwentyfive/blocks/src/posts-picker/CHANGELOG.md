# Changelog

## [1.0.0] - 24-09-2025
### Added
- Initial release of the Posts Picker block.
- Setting up solid modular structure for edit.js (scripts folder for partials) and render.php (lib folder for partials).

