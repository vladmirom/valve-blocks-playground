# Posts Picker Block

## Demo
Demo can be tested on the [Playground](https://playground.wordpress.net/?blueprint-url=https://raw.githubusercontent.com/vladmirom/valve-blocks-playground/refs/heads/main/posts-picker/blueprint.json).

## Purpose
The default core/query-block doesn't allow to select specific posts. This block aims to cover that gap. The user can select block posts from a specific post type. Pre-defined layouts can be applied to the post type selection, therefore, one block can provide various layout and styles. User can define the order of posts to be displayed.

## Features
- Uses modular structure, all .php files (Frontent) are in `/lib` folder (mind namespace), all .js files (Editor) are in `/scripts` folder. This structure better separates concerns.
- Developer has the 2 folder where specific layouts can be defined per post type.
- The scripts/layouts folder includes default PostsLayout.js as an example for editor.
- The lib/layouts folder includes default PostsLayout.php as an example for frontend.
- User has the ability to select the post type and then special posts from this post type. User can chage the order they are shown on the page.
- Block uses default REST API endpoints that WordPress generates for post types.

## Usage
### Preparation
1. Make sure that the post types that you plan to use have REST API enabled during their registration. Use this parameter: `'show_in_rest' => true,`. 
2. Check that the post type REST API endpoint is available, follow this address (considering that you have at least 1 post in that post type): `https://yoursite.local/wp-json/wp/v2/post_type`. By default this block uses posts, if you want to check default posts: `https://yoursite.local/wp-json/wp/v2/posts`.

### Block setup
3. Drop the folder `posts-picker` to `theme/blocks/src` folder. 
4. Run `npm start` in the `theme/blocks` folder in the terminal.
5. Include the `theme/blocks/build/posts-picker` in your `theme/lib/FullSiteEditor/Blocks.php` to the `theme_register_blocks()` function.

### Editing
6. Open `block.json` add the post types you want to use in the block. Post types should be added in format `"post_type_slug": "PostTypeLabel"`. Label is used in the dropdown select and in the layout file name.
7. Open `scripts/layouts` and add a layout for this post type (for editor). The name should be `PostTypeLabelLayout.js`. Eg: `PostsLayout.js`.
8. Open `lib/Layouts` and add a layout for this post type (for frontend). The name should be `PostTypeLabelLayout.php`. Eg: `PostsLayout.php`.
9. No need to modify `edit.js`, it should only pull your layout file and save the selection of your posts.
10. Modify `editor.scss` to define styles of layout in admin area.
11. No need to modify `render.php`, it should only pull your layout file where the main changes should happen.
12. Modify `style.scss` to define styles of layout on the front end.
13. Optional: remove this README.md file.
