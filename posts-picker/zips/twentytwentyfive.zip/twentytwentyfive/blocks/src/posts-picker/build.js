#!/usr/bin/env node

/**
 * Build script for Posts Picker Block
 *
 * This script helps with building and debugging the dynamic layout system
 */

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

console.log('🚀 Building Posts Picker Block...\n');

// Check if node_modules exists
if (!fs.existsSync('node_modules')) {
    console.log('📦 Installing dependencies...');
    try {
        execSync('npm install', { stdio: 'inherit' });
        console.log('✅ Dependencies installed successfully\n');
    } catch (error) {
        console.error('❌ Failed to install dependencies:', error.message);
        process.exit(1);
    }
}

// Clean build directory
console.log('🧹 Cleaning build directory...');
if (fs.existsSync('build')) {
    fs.rmSync('build', { recursive: true, force: true });
}
console.log('✅ Build directory cleaned\n');

// Build the project
console.log('🔨 Building project...');
try {
    execSync('npm run build', { stdio: 'inherit' });
    console.log('✅ Build completed successfully\n');
} catch (error) {
    console.error('❌ Build failed:', error.message);
    process.exit(1);
}

// Check if build files exist
const buildFiles = ['build/posts-picker.js', 'build/posts-picker-editor.js'];
const missingFiles = buildFiles.filter(file => !fs.existsSync(file));

if (missingFiles.length > 0) {
    console.warn('⚠️  Missing build files:', missingFiles.join(', '));
} else {
    console.log('✅ All build files created successfully');
}

console.log('\n🎉 Build process completed!');
console.log('\n📁 Build files:');
buildFiles.forEach(file => {
    if (fs.existsSync(file)) {
        const stats = fs.statSync(file);
        console.log(`   ${file} (${(stats.size / 1024).toFixed(2)} KB)`);
    }
});

console.log('\n💡 Next steps:');
console.log('   1. Check the browser console for any dynamic import errors');
console.log('   2. Verify that the layout files are being loaded correctly');
console.log('   3. Test the block in the WordPress editor');
