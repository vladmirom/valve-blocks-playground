/**
 * Edit Component for WordPress Block
 *
 * This is the main edit component that renders the block in the WordPress editor.
 * It handles the block's visual representation and user interactions in the admin area.
 *
 * @file edit.js
 * @since 1.0.0
 */

import { useState, useEffect } from '@wordpress/element';
import apiFetch from '@wordpress/api-fetch';
import {
	useBlockProps,
	CustomBlockControls,
	generateBlockId,
	__
} from './scripts';

// Import layout manager
import { layoutManager } from './scripts/utils/LayoutManager';

import './editor.scss';

export default function Edit({ attributes, setAttributes, clientId }) {
	const blockProps = useBlockProps();
	const { content = '', blockId, selectedPosts = [], selectedPostType = '' } = attributes;
	const [fetchedPosts, setFetchedPosts] = useState([]);
	const [isLoading, setIsLoading] = useState(false);
	const [renderedContent, setRenderedContent] = useState(null);

	// Initialize block ID if not set
	if (!blockId) {
		setAttributes({ blockId: generateBlockId(clientId) });
	}

	// Get current post type from attribute only
	const currentPostType = selectedPostType;

	// Fetch post data when selectedPosts or postType changes
	useEffect(() => {
		const fetchPostData = async () => {
			if (selectedPosts.length === 0 || !currentPostType) {
				setFetchedPosts([]);
				setRenderedContent(null);
				return;
			}

			setIsLoading(true);
			try {
				const fetchedPosts = await Promise.all(
					selectedPosts.map(async (postId) => {
						const post = await apiFetch({
							path: `/wp/v2/${currentPostType}/${postId}`
						});

						let featuredImage = null;
						if (post.featured_media && post.featured_media > 0) {
							try {
								const mediaData = await apiFetch({
									path: `/wp/v2/media/${post.featured_media}?_fields=source_url,alt_text`
								});
								featuredImage = {
									url: mediaData.source_url,
									alt: mediaData.alt_text || ''
								};
							} catch (mediaError) {
								console.error('Error fetching media for post', postId, ':', mediaError);
							}
						}

						return {
							id: post.id,
							title: post.title.rendered || __('Untitled', 'valve-posts-picker'),
							featuredImage,
							excerpt: post.excerpt?.rendered || '',
							content: post.content?.rendered || ''
						};
					})
				);

				setFetchedPosts(fetchedPosts);

				// Render the layout
				const content = await renderBlockContent(fetchedPosts);
				setRenderedContent(content);
			} catch (error) {
				console.error('Error fetching posts:', error);
				setFetchedPosts([]);
				setRenderedContent(null);
			} finally {
				setIsLoading(false);
			}
		};

		fetchPostData();
	}, [selectedPosts, currentPostType]);

	// Render appropriate layout based on post type
	const renderBlockContent = async (posts = fetchedPosts) => {
		if (posts.length === 0) {
			return (
				<div className="posts-picker-preview">
					<h4>{__('Posts Picker Block', 'valve-posts-picker')}</h4>
					<p>{__('No posts selected', 'valve-posts-picker')}</p>
				</div>
			);
		}

		// Use dynamic layout rendering
		if (layoutManager.isPostTypeConfigured(currentPostType)) {
			return await layoutManager.renderLayout(currentPostType, posts, blockId);
		} else {
			return (
				<div className="posts-picker-preview">
					<h4>{__('Posts Picker Block', 'valve-posts-picker')}</h4>
					<p>
						{__('Unknown post type: ', 'valve-posts-picker')}
						<code>{currentPostType}</code>
					</p>
					<p>
						{__('Available post types: ', 'valve-posts-picker')}
						{layoutManager.getPostTypeKeys().join(', ')}
					</p>
				</div>
			);
		}
	};

	return (
		<div {...blockProps}>
			<CustomBlockControls
				attributes={attributes}
				setAttributes={setAttributes}
			/>

			<div data-block-id={blockId}>
				{isLoading ? (
					<div className="posts-picker-preview">
						<h4>{__('Posts Picker Block', 'valve-posts-picker')}</h4>
						<p>{__('Loading posts...', 'valve-posts-picker')}</p>
					</div>
				) : (
					renderedContent || (
						<div className="posts-picker-preview">
							<h4>{__('Posts Picker Block', 'valve-posts-picker')}</h4>
							<p>{__('No posts selected', 'valve-posts-picker')}</p>
						</div>
					)
				)}
			</div>
		</div>
	);
}
