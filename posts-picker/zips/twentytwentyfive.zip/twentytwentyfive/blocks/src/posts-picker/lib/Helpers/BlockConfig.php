<?php
/**
 * Block configuration helper
 *
 * Reads configuration from block.json and provides helper methods
 * for accessing post types and layout information.
 *
 * @package PostsPicker\Helpers
 */

namespace PostsPicker\Helpers;

class BlockConfig {

    /**
     * Cached configuration data
     *
     * @var array|null
     */
    private static $config = null;

    /**
     * Get the full configuration from block.json
     *
     * @return array
     */
    public static function getConfig() {
        if (self::$config === null) {
            $blockJsonPath = __DIR__ . '/../../block.json';

            if (!file_exists($blockJsonPath)) {
                self::$config = [];
                return self::$config;
            }

            $blockJsonContent = file_get_contents($blockJsonPath);
            $blockData = json_decode($blockJsonContent, true);
            self::$config = $blockData['customConfig'] ?? [];
        }

        return self::$config;
    }

    /**
     * Get available post types from configuration
     *
     * @return array Array of post types with their labels
     */
    public static function getPostTypes() {
        $config = self::getConfig();
        return $config['postTypes'] ?? [];
    }

    /**
     * Get the label for a specific post type
     *
     * @param string $postType The post type key
     * @return string|null The post type label or null if not found
     */
    public static function getPostTypeLabel($postType) {
        $postTypes = self::getPostTypes();
        return $postTypes[$postType] ?? null;
    }

    /**
     * Get the layout class name for a specific post type
     *
     * @param string $postType The post type key
     * @return string|null The layout class name or null if not found
     */
    public static function getLayoutClassName($postType) {
        $label = self::getPostTypeLabel($postType);
        return $label ? $label . 'Layout' : null;
    }

    /**
     * Check if a post type is configured
     *
     * @param string $postType The post type key
     * @return bool True if post type is configured, false otherwise
     */
    public static function isPostTypeConfigured($postType) {
        $postTypes = self::getPostTypes();
        return isset($postTypes[$postType]);
    }

    /**
     * Get all configured post type keys
     *
     * @return array Array of post type keys
     */
    public static function getPostTypeKeys() {
        return array_keys(self::getPostTypes());
    }
}
