<?php
/**
 * Layout handler for Posts post type
 *
 * @package PostsPicker\Layouts
 */

namespace PostsPicker\Layouts;

class PostsLayout {

	/**
	 * Get post meta value for a given post and meta key.
	 *
	 * @param int $post_id The post ID.
	 * @param string $meta_key The meta key.
	 * @return mixed The meta value, or null if not found.
	 */
	private static function get_post_meta_value($post_id, $meta_key) {
		if (empty($post_id) || empty($meta_key)) {
			return null;
		}
		$value = get_post_meta($post_id, $meta_key, true);
		return $value !== '' ? $value : null;
	}

	/**
	 * Render posts layout
	 *
	 * @param array $selected_posts Array of selected posts
	 * @param string $block_id Block ID for styling
	 * @return void
	 */
	public static function render($selected_posts, $block_id) {
	$o = '';

	if (!empty($selected_posts)) {
		$o .= '<div class="post-teasers">';

		foreach ($selected_posts as $post_id) {
			// Prepare data.
			$post_id = intval($post_id);
			$post_obj = get_post($post_id);

			$title = !empty($post_obj) && !empty($post_obj->post_title) ? esc_html($post_obj->post_title) : esc_html__('Untitled', 'valve-posts-picker');
			$excerpt = has_excerpt($post_id) ? get_the_excerpt($post_id) : ($post_obj ? $post_obj->post_content : '');
			$post_link = $post_obj ? get_permalink($post_obj) : '';

			$featured_image = null;
			if (isset($post_obj) && $post_obj instanceof \WP_Post && has_post_thumbnail($post_obj->ID)) {
				$image_id = get_post_thumbnail_id($post_obj->ID);
				$image_url = wp_get_attachment_image_url($image_id, 'full');
				$image_alt = get_post_meta($image_id, '_wp_attachment_image_alt', true);
				if ($image_url) {
					$featured_image = [
						'url' => $image_url,
						'alt' => $image_alt ?: ''
					];
				}
			}

			// Render HTML output.
			$o .= '<div class="post-teaser">';

				// Featured Image.
				if ($featured_image && !empty($featured_image['url'])) {
					$o .= '<div class="post-teaser__image">';
						$img_url = esc_url($featured_image['url']);
						$img_alt = isset($featured_image['alt']) ? esc_attr($featured_image['alt']) : $title;
						$o .= '<img src="' . $img_url . '" alt="' . $img_alt . '" />';
					$o .= '</div>';
				}

				// Post Title.
				$o .= '<h4 class="post-teaser__title">' . $title . '</h4>';

				// Preview Content.
				$has_excerpt = !empty($excerpt) && trim(strip_tags($excerpt));
				if ($has_excerpt) {
					$plain_excerpt = trim(strip_tags($excerpt));
					$words = preg_split('/\s+/', $plain_excerpt, -1, PREG_SPLIT_NO_EMPTY);
					$first_20 = array_slice($words, 0, 20);
					$short_excerpt = implode(' ', $first_20);
					if (count($words) > 20) {
						$short_excerpt .= '…';
					}
					$o .= '<div class="post-teaser__content">' . esc_html($short_excerpt) . '</div>';
				}

				// Read More Button.
				$o .= '<div class="post-teaser__button">';
					$o .= '<a href="';
					$o .= $post_link ? esc_url($post_link) . '"' : '#"';
					$o .= ' class="post-teaser__button-link">';
						$o .= esc_html__('Read more', 'valve-posts-picker');
					$o .= '</a>';
				$o .= '</div>';

			$o .= '</div>'; // .post-teaser
		}

		$o .= '</div>'; // .post-teasers
	}

	echo $o;

	}
}
