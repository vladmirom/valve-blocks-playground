<?php
/**
 * Server rendering of the block.
 * @var $attributes array Block attributes
 * @var $content string Block inner content
 * @var $block WP_Block_Parser_Block The parsed block object
 */

// Load the autoloader
require_once __DIR__ . '/lib/autoload.php';

// Import helper class
use PostsPicker\Helpers\BlockConfig;

// Extract attributes
$content = $attributes['content'] ?? '';
$block_id = $attributes['blockId'] ?? '';
$selected_posts = $attributes['selectedPosts'] ?? [];

// Get post type from saved attribute
$post_type = $attributes['selectedPostType'] ?? '';

// Validate and filter post IDs
if (!empty($selected_posts) && !empty($post_type)) {
    $selected_posts = array_filter($selected_posts, function($post_id) {
        $post = get_post($post_id);
        return $post && $post->post_status === 'publish';
    });
}

$block_wrapper = get_block_wrapper_attributes([
	'class' => 'wp-block-posts-picker-block',
	'data-block-id' => esc_attr($block_id)
]);
?>

<div <?php echo $block_wrapper; ?>>
	<?php if (!empty($selected_posts) && !empty($post_type)) : ?>
		<?php
		// Get layout class name from configuration
		$layout_class_name = BlockConfig::getLayoutClassName($post_type);

		if ($layout_class_name && BlockConfig::isPostTypeConfigured($post_type)) {
			// Dynamically call the appropriate layout
			$full_class_name = "PostsPicker\\Layouts\\{$layout_class_name}";

			if (class_exists($full_class_name)) {
				$full_class_name::render($selected_posts, $block_id);
			} else {
				echo '<p>' . esc_html(__('Layout class not found: ', 'valve-posts-picker')) . esc_html($layout_class_name) . '</p>';
			}
		} else {
			echo '<p>' . esc_html(__('Unknown post type: ', 'valve-posts-picker')) . esc_html($post_type) . '</p>';
		}
		?>
	<?php else : ?>
		<p><?php echo esc_html(__('No posts selected', 'valve-posts-picker')); ?></p>
	<?php endif; ?>
</div>
