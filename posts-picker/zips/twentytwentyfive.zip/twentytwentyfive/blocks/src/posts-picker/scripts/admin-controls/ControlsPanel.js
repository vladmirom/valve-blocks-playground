/**
 * Control panel for block settings
 *
 * @file ControlsPanel.js
 */

import {
	PanelBody,
	PanelRow,
	SelectControl,
	Button,
	Notice,
	Spinner,
	Tooltip
} from '@wordpress/components';
import { __ } from '@wordpress/i18n';
import { useState, useLayoutEffect } from '@wordpress/element';
import apiFetch from '@wordpress/api-fetch';
import { POST_TYPES_FINAL } from '../utils/BlockConstants';

const ControlsPanel = ({ attributes, setAttributes }) => {
	const { selectedPosts = [], selectedPostType = '' } = attributes;
	const [selectedPostId, setSelectedPostId] = useState('');
	const [posts, setPosts] = useState([]);
	const [isLoading, setIsLoading] = useState(false);
	const [fetchError, setFetchError] = useState('');

	// Initialize selectedPostType from attribute only (since we no longer store type in selectedPosts)
	const currentPostType = selectedPostType;

	// Check if post type selection should be disabled (when posts are already selected)
	const hasSelectedPosts = selectedPosts.length > 0;
	const isPostTypeSelectionDisabled = hasSelectedPosts;

	// Fetch posts on component mount if there's already a post type selected
	useLayoutEffect(() => {
		if (currentPostType && posts.length === 0 && !isLoading) {
			fetchPosts(currentPostType);
		}
	}, [currentPostType]);

	// Generate post type options from configuration
	const postTypeOptions = [
		{ label: __('Select post type...', 'valve-posts-picker'), value: '' },
		...Object.entries(POST_TYPES_FINAL).map(([key, label]) => ({
			label,
			value: key
		}))
	];

	// Fetch posts when post type changes
	const fetchPosts = async (postType) => {
		if (!postType) {
			setPosts([]);
			return;
		}

		setIsLoading(true);
		setFetchError('');

		try {
			// First fetch posts with all available fields to debug
			const fetchedPosts = await apiFetch({
				path: `/wp/v2/${postType}?per_page=100&status=publish`
			});

			// console.log('Full post data for debugging:', fetchedPosts);

			// Format posts and fetch featured images separately if they exist
			const formattedPosts = await Promise.all(
				fetchedPosts.map(async (post) => {
					let featuredImage = null;

					if (post.featured_media && post.featured_media > 0) {
						try {
							const mediaData = await apiFetch({
								path: `/wp/v2/media/${post.featured_media}?_fields=source_url,alt_text`
							});
							// console.log('Media data for post', post.id, ':', mediaData);

							featuredImage = {
								url: mediaData.source_url,
								alt: mediaData.alt_text || ''
							};
						} catch (mediaError) {
							console.error('Error fetching media for post', post.id, ':', mediaError);
						}
					}

					return {
						id: post.id,
						title: post.title.rendered || __('Untitled', 'valve-posts-picker'),
						featuredImage,
						excerpt: post.excerpt?.rendered || '',
						content: post.content?.rendered || ''
					};
				})
			);

			// console.log('Final formatted posts:', formattedPosts);
			setPosts(formattedPosts);
		} catch (error) {
			console.error('Error fetching posts:', error);
			setFetchError(__('Failed to load posts. Please try again.', 'valve-posts-picker'));
			setPosts([]);
		} finally {
			setIsLoading(false);
		}
	};

	// Handle post type selection
	const handlePostTypeChange = (value) => {
		// Immediately save to block attributes
		setAttributes({ selectedPostType: value });
		setSelectedPostId(''); // Reset post selection
		fetchPosts(value);
	};

	// Handle adding a post
	const handleAddPost = () => {
		if (!selectedPostId) return;

		const selectedPost = posts.find(post => post.id.toString() === selectedPostId);
		if (!selectedPost) return;

		// Check if post is already selected
		const isAlreadySelected = selectedPosts.some(postId => postId === selectedPost.id);
		if (isAlreadySelected) return;

		// Update both selectedPosts and ensure selectedPostType is saved
		setAttributes({
			selectedPosts: [...selectedPosts, selectedPost.id],
			selectedPostType: currentPostType
		});

		// Reset post selection
		setSelectedPostId('');
	};

	// Handle removing a post
	const handleRemovePost = (postId) => {
		const updatedPosts = selectedPosts.filter(id => id !== postId);
		setAttributes({ selectedPosts: updatedPosts });
	};

	// Check if selected post is already in the list
	const isPostAlreadySelected = selectedPostId && selectedPosts.some(postId => postId === parseInt(selectedPostId));

	return (
		<PanelBody title={__('Posts Picker Settings', 'valve-posts-picker')} initialOpen={true}>
			<PanelRow>
				{isPostTypeSelectionDisabled ? (
					<Tooltip text={
						<>
							{__('Mixed post types are not supported in this block.', 'valve-posts-picker')}
							<br />
							{__('Remove selected posts to enable post type selection.', 'valve-posts-picker')}
						</>
					}>
						<div className="wp-block-valve-posts-picker__controls-panel select-row">
							<SelectControl
								label={__('Post Type', 'valve-posts-picker')}
								value={currentPostType}
								options={postTypeOptions}
								onChange={handlePostTypeChange}
								disabled={true}
								style={{ cursor: 'not-allowed' }}
							/>
						</div>
					</Tooltip>
				) : (
					<div className="wp-block-valve-posts-picker__controls-panel select-row">
						<SelectControl
						label={__('Post Type', 'valve-posts-picker')}
						value={currentPostType}
						options={postTypeOptions}
						onChange={handlePostTypeChange}
					/>
					</div>
				)}
			</PanelRow>

			{currentPostType && (
				<PanelRow>
					<div className="wp-block-valve-posts-picker__controls-panel select-row">
						<SelectControl
							label={__('Select Post', 'valve-posts-picker')}
							value={selectedPostId}
							options={[
								{ label: __('Select a post...', 'valve-posts-picker'), value: '' },
								...posts.map(post => ({
									label: post.title,
									value: post.id.toString()
								}))
							]}
							onChange={setSelectedPostId}
							disabled={isLoading || posts.length === 0}
						/>
						{isLoading && (
							<div className="wp-block-valve-posts-picker__controls-panel spinner">
								<Spinner />
							</div>
						)}
					</div>
				</PanelRow>
			)}

			{fetchError && (
				<Notice status="error" isDismissible={false}>
					{fetchError}
				</Notice>
			)}

			{posts.length === 0 && currentPostType && !isLoading && !fetchError && (
				<Notice status="warning" isDismissible={false}>
					{__('No posts found for the selected post type.', 'valve-posts-picker')}
				</Notice>
			)}

			{isPostAlreadySelected && (
				<Notice status="info" isDismissible={false}>
					{__('This post is already selected.', 'valve-posts-picker')}
				</Notice>
			)}

			<PanelRow>
				<Button
					variant="primary"
					onClick={handleAddPost}
					disabled={!selectedPostId || isPostAlreadySelected}
				>
					{__('Add Post', 'valve-posts-picker')}
				</Button>
			</PanelRow>

			{selectedPosts.length > 0 && (
				<>
					<hr />
					<h4>{__('Selected Posts', 'valve-posts-picker')}</h4>
				{selectedPosts.map((postId) => {
					const post = posts.find(p => p.id === postId);
					return (
						<div key={postId} className="wp-block-valve-posts-picker__controls-panel selected-post">
							<div>
								<strong>{post ? post.title : `Post ID: ${postId}`}</strong>
							</div>
							<Button
								variant="secondary"
								isDestructive
								size="small"
								onClick={() => handleRemovePost(postId)}
								className="wp-block-valve-posts-picker__controls-panel selected-post__button"
							>
								{__('Remove', 'valve-posts-picker')}
							</Button>
						</div>
					);
				})}
				</>
			)}
		</PanelBody>
	);
};

export default ControlsPanel;
