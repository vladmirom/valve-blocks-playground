/**
 * Layout handler for posts in the editor
 *
 * @file PostsLayout.js
 */

import { __ } from '@wordpress/i18n';

/**
 * Render posts posts in the editor
 *
 * @param {Array} posts - Array of post objects with full data
 * @param {string} blockId - Block ID for styling
 * @returns {JSX.Element}
 */
export const renderPostsLayout = (posts, blockId) => {
	return (
		<div className="post-layout-editor" data-block-id={blockId}>
			{posts.length > 0 && (
				<div className="post-teasers">
					{posts.map((post) => (
						<div key={post.id} className="post-teaser">

							{/* Image Block - Featured Image */}
							<div className="post-teaser__image">
								{post.featuredImage ? (
									<img
										src={post.featuredImage.url}
										alt={post.featuredImage.alt || post.title}
									/>
								) : (
									<div className="post-teaser__image--placeholder">
										📷 {__('No Featured Image', 'valve-posts-picker')}
									</div>
								)}
							</div>

							{/* Person Title */}
							<h4 className="post-teaser__title">
								{post.title}
							</h4>

							{/* Preview Content */}
							<p className="post-teaser__content">
								{post.excerpt && post.excerpt.trim() ? (
									<span>
										{
											(() => {
												// Strip HTML tags and get first 20 words from excerpt
												const text = post.excerpt.replace(/<[^>]+>/g, '').trim();
												const wordsArr = text.split(/\s+/).filter(Boolean);
												const words = wordsArr.slice(0, 20).join(' ');
												return words + (wordsArr.length > 20 ? '…' : '');
											})()
										}
									</span>
								) : (
									<span>
										{__('Current post does not have excerpt.', 'valve-posts-picker')}
									</span>
								)}
							</p>

							{/* Read More Button */}
							<div className="post-teaser__button">
								<a href="#" className="post-teaser__button-link">
									{__('Read more', 'valve-posts-picker')}
								</a>
							</div>

						</div>
					))}
				</div>
			)}
		</div>
	);
};
