/**
 * Constants for the block
 *
 * @file BlockConstants.js
 */

import { __ } from '@wordpress/i18n';
import blockMetadata from '../../block.json';

// Get custom config from block metadata
const customConfig = blockMetadata?.customConfig || {};

// Export post types with translations
export const POST_TYPES = Object.fromEntries(
	Object.entries(customConfig.postTypes || {}).map(([key, value]) => [
		key,
		__(value, 'valve-posts-picker')
	])
);

// Fallback to hardcoded values if block metadata is not available
export const POST_TYPES_FALLBACK = {
	posts: __('Posts', 'valve-posts-picker')
};

// Use fallback if no post types found in config
export const POST_TYPES_FINAL = Object.keys(POST_TYPES).length > 0 ? POST_TYPES : POST_TYPES_FALLBACK;
