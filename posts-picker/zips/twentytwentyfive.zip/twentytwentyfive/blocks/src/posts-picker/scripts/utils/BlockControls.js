/**
 * Block Controls Component
 *
 * Wraps the InspectorControls and includes our custom ControlsPanel
 *
 * @file BlockControls.js
 */

import { InspectorControls } from '@wordpress/block-editor';
import ControlsPanel from '../admin-controls/ControlsPanel';

const BlockControls = ({ attributes, setAttributes }) => {
	return (
		<InspectorControls>
			<ControlsPanel
				attributes={attributes}
				setAttributes={setAttributes}
			/>
		</InspectorControls>
	);
};

export default BlockControls;
