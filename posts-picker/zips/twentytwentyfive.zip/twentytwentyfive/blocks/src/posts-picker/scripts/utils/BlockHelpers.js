/**
 * JavaScript helper functions for the block
 *
 * @file BlockHelpers.js
 */

/**
 * Generate a unique block ID
 * @param {string} clientId - The block's client ID from WordPress
 * @returns {string} - Unique block identifier
 */
export const generateBlockId = (clientId) => {
	return `block-${clientId}-${Date.now()}`;
};
