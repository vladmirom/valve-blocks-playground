/**
 * Layout Manager for dynamic layout loading
 *
 * Handles dynamic imports and rendering of layout components
 * based on post type configuration.
 *
 * @file LayoutManager.js
 */

import { __ } from '@wordpress/i18n';
import { POST_TYPES_FINAL } from './BlockConstants';

class LayoutManager {
    constructor() {
        this.layouts = new Map();
        this.loadedLayouts = new Set();
    }

    /**
     * Load a layout component for a specific post type
     *
     * @param {string} postType The post type key
     * @returns {Promise<Function|null>} The render function or null if not found
     */
    async loadLayout(postType) {
        if (this.loadedLayouts.has(postType)) {
            return this.layouts.get(postType);
        }

        try {
            const label = POST_TYPES_FINAL[postType];
            if (!label) {
                console.warn(`No label found for post type: ${postType}`);
                return null;
            }

            const layoutName = `${label}Layout`;
            const functionName = `render${layoutName}`;

            // Try different import paths to handle build variations
            let module;
            try {
                module = await import(`../layouts/${layoutName}.js`);
            } catch (importError) {
                // Try without .js extension
                try {
                    module = await import(`../layouts/${layoutName}`);
                } catch (altError) {
                    throw importError; // Throw original error
                }
            }

            const renderFunction = module[functionName];

            if (renderFunction) {
                this.layouts.set(postType, renderFunction);
                this.loadedLayouts.add(postType);
                return renderFunction;
            } else {
                console.error(`Render function not found in ${layoutName}.js`);
                return null;
            }
        } catch (error) {
            console.error(`Failed to load layout for ${postType}:`, error);
            return null;
        }
    }

    /**
     * Render a layout for a specific post type
     *
     * @param {string} postType The post type key
     * @param {Array} posts Array of post data
     * @param {string} blockId Block ID for styling
     * @returns {Promise<JSX.Element>} The rendered layout
     */
    async renderLayout(postType, posts, blockId) {
        const renderFunction = await this.loadLayout(postType);

        if (renderFunction) {
            return renderFunction(posts, blockId);
        }

        // Fallback layout
        return (
            <div className="posts-picker-fallback">
                <h4>{__('Posts Picker Block', 'valve-posts-picker')}</h4>
                <p>
                    {__('Layout not found for post type: ', 'valve-posts-picker')}
                    <code>{postType}</code>
                </p>
                <p>
                    {__('Available post types: ', 'valve-posts-picker')}
                    {Object.keys(POST_TYPES_FINAL).join(', ')}
                </p>
            </div>
        );
    }

    /**
     * Check if a post type is configured
     *
     * @param {string} postType The post type key
     * @returns {boolean} True if post type is configured
     */
    isPostTypeConfigured(postType) {
        return postType in POST_TYPES_FINAL;
    }

    /**
     * Get all configured post type keys
     *
     * @returns {Array<string>} Array of post type keys
     */
    getPostTypeKeys() {
        return Object.keys(POST_TYPES_FINAL);
    }
}

// Export singleton instance
export const layoutManager = new LayoutManager();
