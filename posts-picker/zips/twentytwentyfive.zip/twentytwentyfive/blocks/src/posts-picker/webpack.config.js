/**
 * Webpack configuration for Posts Picker Block
 *
 * Optimized for WordPress block development with dynamic import support
 * and proper asset handling for reusability across projects.
 */

const path = require('path');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const CssMinimizerPlugin = require('css-minimizer-webpack-plugin');
const TerserPlugin = require('terser-webpack-plugin');

module.exports = (env, argv) => {
	const isProduction = argv.mode === 'production';

	return {
		entry: {
			'posts-picker': './index.js',
			'posts-picker-editor': './edit.js',
		},

		output: {
			path: path.resolve(__dirname, 'build'),
			filename: '[name].js',
			clean: true,
			// Enable dynamic imports
			chunkFilename: '[name].[chunkhash].js',
		},

		module: {
			rules: [
				{
					test: /\.js$/,
					exclude: /node_modules/,
					use: {
						loader: 'babel-loader',
						options: {
							presets: [
								['@babel/preset-env', {
									targets: { node: 'current' },
									modules: false // Keep ES modules for dynamic imports
								}],
								['@babel/preset-react', { runtime: 'automatic' }]
							],
							plugins: [
								'@babel/plugin-syntax-dynamic-import',
								'@babel/plugin-proposal-class-properties',
								'@babel/plugin-transform-runtime'
							]
						}
					}
				},
				{
					test: /\.scss$/,
					use: [
						isProduction ? MiniCssExtractPlugin.loader : 'style-loader',
						{
							loader: 'css-loader',
							options: {
								sourceMap: !isProduction,
								importLoaders: 2
							}
						},
						{
							loader: 'postcss-loader',
							options: {
								postcssOptions: {
									plugins: [
										['autoprefixer', {}],
										...(isProduction ? [['cssnano', {}]] : [])
									]
								}
							}
						},
						{
							loader: 'sass-loader',
							options: {
								sourceMap: !isProduction
							}
						}
					]
				},
				{
					test: /\.svg$/,
					use: ['@svgr/webpack']
				}
			]
		},

		plugins: [
			new MiniCssExtractPlugin({
				filename: '[name].css'
			})
		],

		optimization: {
			minimize: isProduction,
			minimizer: [
				new TerserPlugin({
					terserOptions: {
						compress: {
							drop_console: isProduction
						}
					}
				}),
				new CssMinimizerPlugin()
			],
			splitChunks: {
				chunks: 'all',
				cacheGroups: {
					vendor: {
						test: /[\\/]node_modules[\\/]/,
						name: 'vendors',
						chunks: 'all',
					},
					// Create separate chunks for layouts to support dynamic imports
					layouts: {
						test: /[\\/]scripts[\\/]layouts[\\/]/,
						name: 'layouts',
						chunks: 'async',
						enforce: true
					}
				}
			}
		},

		resolve: {
			extensions: ['.js', '.jsx', '.scss'],
			alias: {
				'@': path.resolve(__dirname, 'scripts'),
				'@layouts': path.resolve(__dirname, 'scripts/layouts'),
				'@utils': path.resolve(__dirname, 'scripts/utils'),
				'@controls': path.resolve(__dirname, 'scripts/admin-controls')
			}
		},

		devtool: isProduction ? 'source-map' : 'eval-source-map',

		externals: {
			'@wordpress/blocks': 'wp.blocks',
			'@wordpress/block-editor': 'wp.blockEditor',
			'@wordpress/components': 'wp.components',
			'@wordpress/element': 'wp.element',
			'@wordpress/i18n': 'wp.i18n',
			'@wordpress/api-fetch': 'wp.apiFetch'
		}
	};
};
